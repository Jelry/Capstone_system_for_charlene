<?php

namespace App\Http\Controllers;

use App\Models\completed_event_photos;
use Illuminate\Http\Request;

class CompletedEventPhotosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\completed_event_photos  $completed_event_photos
     * @return \Illuminate\Http\Response
     */
    public function show(completed_event_photos $completed_event_photos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\completed_event_photos  $completed_event_photos
     * @return \Illuminate\Http\Response
     */
    public function edit(completed_event_photos $completed_event_photos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\completed_event_photos  $completed_event_photos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, completed_event_photos $completed_event_photos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\completed_event_photos  $completed_event_photos
     * @return \Illuminate\Http\Response
     */
    public function destroy(completed_event_photos $completed_event_photos)
    {
        //
    }
}
