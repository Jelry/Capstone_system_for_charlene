<img src="<?php echo e(asset('app_logo/main.png')); ?>" alt="">

<?php /**PATH C:\Users\Jelry\Desktop\greenisenos\resources\views/components/application-logo.blade.php ENDPATH**/ ?>