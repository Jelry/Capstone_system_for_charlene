<img src="<?php echo e(asset('app_logo/main.png')); ?>" alt="">

<?php /**PATH F:\clients\cha\main\resources\views/components/application-logo.blade.php ENDPATH**/ ?>