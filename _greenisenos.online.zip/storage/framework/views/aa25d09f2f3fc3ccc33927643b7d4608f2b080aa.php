<?php echo e($slot); ?>

<?php /**PATH /home/u365647791/domains/greenisenos.online/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>