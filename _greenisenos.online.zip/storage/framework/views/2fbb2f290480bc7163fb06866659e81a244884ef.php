<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 

     <?php $__env->endSlot(); ?>
    <div class="py-12 grid grid-cols-1 lg:grid-cols-5">
        
            <div class="col-span-1"></div>
            <div class="col-span-3 bg-white w-full">
                <div class="flex items-center">
                    <h1 class="pl-6">Joined as</h1>
                    <select name="" id="volunteer_as" class="m-4 rounded shadow" onchange="display_org_names_input()" >
                        <option value="individual">individual</option>
                        <option value="organization">organization</option>
                    </select> 
                   
                </div>
           
             <div id="indi_view" class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left text-gray-500 ">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 ">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Joined As
                            </th>
                            <th scope="col" class="px-6 py-3">
                                email used
                            </th>
                            <th scope="col" class="px-6 py-3">
                                phone number used
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Joined Date
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $my_bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indi_bookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($indi_bookings->type_of_volunteer=="individual"): ?>
                        <tr class="bg-white border-b ">
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap ">
                              
                                Individual
                             
                           
                            </th>
                            <td class="px-6 py-4">
                                <?php echo e($indi_bookings->email); ?>

                            </td>
                            <td class="px-6 py-4">
                               <?php echo e($indi_bookings->phone_number); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e(Carbon\Carbon::parse($indi_bookings->created_at)->format('Y-m-d')); ?>

                            </td>
                            <td class="px-6 py-4">
                                <a href="/view_activity/<?php echo e($indi_bookings->activity_id); ?>" class="font-medium text-blue-600  hover:underline">View</a>
                            </td>
                        </tr>   
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>
                </table>
            </div>
           

<div id="org_view" class="relative overflow-x-auto shadow-md sm:rounded-lg hidden">
    <table class="w-full text-sm text-left text-gray-500 ">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 ">
            <tr>
                <th scope="col" class="px-6 py-3">
                    Joined As
                </th>
                <th scope="col" class="px-6 py-3">
                    email used
                </th>
                <th scope="col" class="px-6 py-3">
                    phone number used
                </th>
                <th scope="col" class="px-6 py-3">
                    Date Joined
                </th>
                <th scope="col" class="px-6 py-3">
                    Action
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $my_bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org_bookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($org_bookings->type_of_volunteer=="organization"): ?>
            <tr>
                <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap ">
                 Organization
                </th>
                <td class="px-6 py-4">
                    <?php echo e($org_bookings->point_person_email); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($org_bookings->point_person_phone_number); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e(Carbon\Carbon::parse($org_bookings->created_at)->format('Y-m-d')); ?>

                </td>
                <td class="px-6 py-4">
                    <a href="/view_activity/<?php echo e($org_bookings->activity_id); ?>" class="font-medium text-blue-600  hover:underline">View</a>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </tbody>
    </table>
</div>
            </div>
            <div class="col-span-1"></div>

        

    </div>
    <script>
        function display_org_names_input()
        {
          var i=document.getElementById('volunteer_as').value;
          if(i=="individual")
          {
           document.getElementById('org_view').style.display = 'none';
           document.getElementById('indi_view').style.display = 'block';
          }
          else{
            document.getElementById('org_view').style.display = 'block';
           document.getElementById('indi_view').style.display = 'none';
          }
        }
      </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Jelry\Desktop\greenisenos\resources\views/volunteer/my_bookings.blade.php ENDPATH**/ ?>