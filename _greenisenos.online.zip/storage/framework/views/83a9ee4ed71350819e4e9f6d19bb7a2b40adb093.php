<img src="<?php echo e(asset('app_logo/main.png')); ?>" alt="">

<?php /**PATH F:\clients\cha\from hosting\resources\views/components/application-logo.blade.php ENDPATH**/ ?>