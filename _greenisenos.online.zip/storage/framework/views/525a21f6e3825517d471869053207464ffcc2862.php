<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            <?php echo e(__('Latest Activities')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="p-6 text-gray-900 grid grid-cols-1 lg:grid-cols-5 gap-3">
           <div class="col-span-1">
          </div>        
        <div class="col-span-3">
          <?php $__currentLoopData = $env_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div
  
  class="relative block overflow-hidden rounded-lg border border-gray-100 p-8 bg-white shadow mb-4"
>
  

  <div class="justify-between sm:flex">
    <div>
      <h3 class="text-xl font-bold text-gray-900">
       <?php echo e($item->act_name); ?>

      </h3>

      <p class="mt-1 text-xs font-medium text-teal-600">Event Date: <?php echo e($item->act_date); ?></p>
    </div>

    <div class="ml-3 hidden flex-shrink-0 sm:block">
      <img
        alt="error image"
        src="https://images.unsplash.com/photo-1502082553048-f009c37129b9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80"
        class="h-16 w-16 rounded-lg object-cover shadow-sm"
      />
    </div>
  </div>

  <div class="mt-4 sm:pr-8">
    <p class="text-sm text-gray-500">
      <?php echo e($item->act_desc); ?>

    </p>
  </div>

  <dl class="mt-6 flex grid grid-cols-5">
   
   
      <div class="flex flex-col-reverse">
        <dt class="text-sm font-medium text-gray-600">Published</dt>
        <dd class="text-xs text-gray-500"><?php echo e(Carbon\Carbon::parse($item->created_at)->format('Y-m-d')); ?></dd>
      </div>
  
      <div class="ml-3 flex flex-col-reverse sm:ml-6">
        <dt class="text-sm font-medium text-green-700">Volunteers</dt>
        <dd class="text-xs text-gray-500">
          <?php
           $v_count=0;   
          ?>
          <?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($v->activity_id==$item->id): ?>
          <?php
          $v_count++;
          ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($v_count); ?>

        </dd>
      </div>
      <div class="col-span-3 flex justify-end">
        <a
        class="group relative inline-block overflow-hidden border border-indigo-600 px-4 py-1 focus:outline-none focus:ring"
        href="/view_activity/<?php echo e($item->id); ?>"
      >
        <span
          class="absolute inset-y-0 left-0 w-[2px] bg-indigo-600 transition-all group-hover:w-full group-active:bg-indigo-500"
        ></span>
      
        <span
          class="relative text-sm font-medium text-indigo-600 transition-colors group-hover:text-white"
        >
          View
        </span>
      </a>
      </div>
    
  </dl>
  
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="col-span-1">
        </div>
    </div>
    </div>
   

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH E:\Users\casca\Desktop\cha\main project\greenisenos\resources\views/dashboard.blade.php ENDPATH**/ ?>